#!/bin/bash
# Setup script for Pico Flight Controller project
# Fetches microzig and updates build.zig.zon with correct hash

set -e

MICROZIG_URL="https://github.com/ZigEmbeddedGroup/microzig/releases/download/0.15.0/microzig.tar.gz"

echo "=== Pico Flight Controller Setup ==="
echo ""

# Check Zig version
echo "Checking Zig installation..."
if ! command -v zig &> /dev/null; then
    echo "ERROR: Zig not found. Please install Zig 0.15.1"
    echo "  Download from: https://ziglang.org/download/"
    exit 1
fi

ZIG_VERSION=$(zig version)
echo "Found Zig version: $ZIG_VERSION"

if [[ ! "$ZIG_VERSION" == 0.15* ]]; then
    echo "WARNING: MicroZig 0.15.0 requires Zig 0.15.x"
    echo "  You have: $ZIG_VERSION"
    echo "  Expected: 0.15.1"
    echo ""
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo ""
echo "Fetching microzig dependency..."
echo "This will download ~50MB and may take a moment..."
echo ""

# Fetch microzig and save to build.zig.zon
zig fetch --save "$MICROZIG_URL"

echo ""
echo "=== Setup Complete ==="
echo ""
echo "You can now build with:"
echo "  zig build"
echo ""
echo "Or use the Makefile:"
echo "  make build"
echo "  make flash"
