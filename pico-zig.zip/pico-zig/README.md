# Pico Flight Controller - Hello World

Zig-based blink example for Raspberry Pi Pico using MicroZig.

## Prerequisites

**Zig 0.15.1** is required. Check your version:
```bash
zig version
```

Download from: https://ziglang.org/download/

## Quick Setup

```bash
# 1. Run the setup script (fetches microzig)
chmod +x setup.sh
./setup.sh

# 2. Build
zig build

# 3. Flash to Pico
make flash
```

## Manual Setup

If the setup script doesn't work:

```bash
# Fetch microzig and update build.zig.zon
zig fetch --save https://github.com/ZigEmbeddedGroup/microzig/releases/download/0.15.0/microzig.tar.gz

# Build
zig build
```

## Output Files

After building:
```
zig-out/
└── firmware/
    ├── pico-blink.uf2   <- Flash this
    └── pico-blink.elf   <- For debugging
```

## Flash to Pico

1. Hold the **BOOTSEL** button on your Pico
2. Plug in USB (while holding button)
3. Release button — Pico mounts as `RPI-RP2`
4. Copy the `.uf2` file:
   ```bash
   # Linux
   cp zig-out/firmware/pico-blink.uf2 /media/$USER/RPI-RP2/
   
   # macOS
   cp zig-out/firmware/pico-blink.uf2 /Volumes/RPI-RP2/
   
   # Or use make
   make flash      # Linux
   make flash-mac  # macOS
   ```

5. Pico reboots automatically — LED should blink!

## Troubleshooting

**"no module named 'microzig'"**
Run setup.sh or `zig fetch --save <url>` first.

**Hash mismatch error**
Delete `.zig-cache` and run setup again.

**Wrong Zig version**
MicroZig 0.15.0 requires Zig 0.15.x

## Project Structure

```
pico-zig/
├── build.zig       # Build configuration
├── build.zig.zon   # Dependencies
├── Makefile        # Convenience targets
├── setup.sh        # Setup script
└── src/
    └── main.zig    # Your code
```

## Next Steps

Once this works, we'll add:
1. UART serial output
2. I2C for IMU communication  
3. PWM output for ESC control
4. Sensor fusion algorithms
